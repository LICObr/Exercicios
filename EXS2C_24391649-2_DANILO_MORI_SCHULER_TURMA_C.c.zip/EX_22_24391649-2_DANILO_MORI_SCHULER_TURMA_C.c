#include <stdio.h>

int main() {
    int escolha;
    double temp, resultado;
    
    printf("1. Celsius para Fahrenheit\n");
    printf("2. Fahrenheit para Celsius\n");
    printf("Digite sua escolha (1 ou 2): ");
    scanf("%d", &escolha);
    
    if (escolha == 1) {
        printf("Digite a temperatura em Celsius: ");
        scanf("%lf", &temp);
        resultado = (temp * 9 / 5) + 32;
        printf("%.2f graus Celsius � igual a %.2f graus Fahrenheit\n", temp, resultado);
    } else if (escolha == 2) {
        printf("Digite a temperatura em Fahrenheit: ");
        scanf("%lf", &temp);
        resultado = (temp - 32) * 5 / 9;
        printf("%.2f graus Fahrenheit � igual a %.2f graus Celsius\n", temp, resultado);
    } else {
        printf("Escolha inv�lida.\n");
    }
    
    return 0;
}
