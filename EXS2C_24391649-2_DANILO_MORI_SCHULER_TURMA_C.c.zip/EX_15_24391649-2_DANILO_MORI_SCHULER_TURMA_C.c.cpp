#include <stdio.h>

int main() {
    char senha[100];
    int i;
    int comprimento = 0;
    int tm = 0, tmm = 0, tn = 0, te = 0;
    
    printf("Digite a senha");
    scanf("%99s", senha); 

    while (senha[comprimento] != '\0') {
        comprimento++;
    }
    
    if (comprimento < 8) {
        printf("Senha inv�lida: A senha deve ter pelo menos 8 caracteres.\n");
        return 1;
    }
    
    for (i = 0; i < comprimento; i++) {
        if (senha[i] >= 'A' && senha[i] <= 'Z') {
            tm = 1;
        } else if (senha[i] >= 'a' && senha[i] <= 'z') {
            tmm = 1;
        } else if (senha[i] >= '0' && senha[i] <= '9') {
            tn = 1;
        } else {
            te = 1;
        }
    }
    if (tm && tmm && tn && te) {
        printf("Senha v�lida.\n");
    } else {
        printf("Senha inv�lida: A senha deve conter pelo menos uma letra mai�scula, uma letra min�scula, um n�mero e um caractere especial.\n");
    }

    return 0;
}
