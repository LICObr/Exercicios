#include <stdio.h>

int main() {
    int qtd;          
    float pu, pt;     
    pu = 20.0;

 
    printf("Digite a quantidade de livros: ");
    scanf("%d", &qtd);

    if (qtd > 10) {
        pt = qtd * pu * 0.90; 
    } else if (qtd >= 5) {
        pt = qtd * pu * 0.95;  
    } else {
        pt = qtd * pu;  
    }
    
    printf("O pre�o total da compra �: R$ %.2f\n", pt);

    return 0;
}
