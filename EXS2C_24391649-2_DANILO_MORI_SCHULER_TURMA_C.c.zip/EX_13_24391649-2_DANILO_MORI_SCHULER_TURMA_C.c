#include <stdio.h>

int main() {
    int pontos;

    printf("Digite a quantidade de pontos ganhos: ");
    scanf("%d", &pontos);

    if (pontos < 0) {
        printf("Quantidade de pontos inv�lida.\n");
    } else if (pontos <= 100) {
        printf("N�vel de premia��o: B�sico\n");
    } else if (pontos <= 200) {
        printf("N�vel de premia��o: Intermedi�rio\n");
    } else {
        printf("N�vel de premia��o: Avan�ado\n");
    }

    return 0;
}
