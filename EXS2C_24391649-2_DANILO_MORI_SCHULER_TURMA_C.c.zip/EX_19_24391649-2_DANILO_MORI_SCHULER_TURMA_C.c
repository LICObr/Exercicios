#include <stdio.h>
double calcSensTerm(double temp, double umid) {
    return temp + (0.1 * umid);
}

int main() {
    double temp, umid, sensTerm;
    
    printf("Digite a temperatura (em graus Celsius): ");
    scanf("%lf", &temp);
    
    printf("Digite a umidade (em porcentagem): ");
    scanf("%lf", &umid);
    
    if (temp < -50 || temp > 60 || umid < 0 || umid > 100) {
        printf("Valores de temperatura ou umidade fora do intervalo.\n");
        return 1;
    }
    
    sensTerm = calcSensTerm(temp, umid);
    
    printf("A sensa��o t�rmica �: %.2f graus Celsius\n", sensTerm);
    
    return 0;
}
