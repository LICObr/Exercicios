#include <stdio.h>

int main() {
    int nPessoas;
    char tr, al, ex;
    float cBase, cTotal;
    
    float pBase = 1000.0; 
    float cTr = 150.0; 
    float cAl = 100.0; 
    float cEx = 200.0; 

    printf("Digite o n�mero de pessoas: ");
    scanf("%d", &nPessoas);

    printf("Deseja adicionar transporte (s/n)? ");
    scanf(" %c", &tr);
    printf("Deseja adicionar alimenta��o (s/n)? ");
    scanf(" %c", &al);
    printf("Deseja adicionar excurs�o (s/n)? ");
    scanf(" %c", &ex);

    cTotal = pBase * nPessoas;
    
//add custos

    if (tr == 's' || tr == 'S') {
        cTotal += cTr * nPessoas;
    }
    if (al == 's' || al == 'S') {
        cTotal += cAl * nPessoas;
    }
    if (ex == 's' || ex == 'S') {
        cTotal += cEx * nPessoas;
    }

    printf("O custo total da viagem �: R$ %.2f\n", cTotal);

    return 0;
}
