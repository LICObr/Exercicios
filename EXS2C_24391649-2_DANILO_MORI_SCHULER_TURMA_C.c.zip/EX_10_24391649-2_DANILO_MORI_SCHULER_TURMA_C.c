#include <stdio.h>

int main() {
    int alunos;
    float nota, soma, media;

    printf("Digite o n�mero de alunos: ");
    scanf("%d", &alunos);

    for (int i = 0; i < alunos; i++) {
        printf("Digite a nota do aluno %d (entre 0 e 10): ", i + 1);
        scanf("%f", &nota);

        while (nota < 0 || nota > 10) {
            printf("Nota inv�lida.");
            scanf("%f", &nota);
        }

        somaNotas += nota;
    }

    media = soma / alunos;

    if (media < 5) {
        printf("A m�dia das notas �: %.2f\n", media);
        printf("Reprovada\n");
        
    } else if (media <= 7) {
        printf("A m�dia das notas �: %.2f\n", media);
        printf("Em recupera��o\n");
        
    } else {
        printf("A m�dia das notas �: %.2f\n", media);
        printf("Aprovada\n");
    }

    return 0;
}
