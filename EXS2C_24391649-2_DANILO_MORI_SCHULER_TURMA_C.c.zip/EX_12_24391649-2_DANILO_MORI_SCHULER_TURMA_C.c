#include <stdio.h>

int main() {
    
    float taxab = 50.0;  
    float taxakm = 0.75;
    float kmr, vtot;

    printf("Digite a quantidade de quil�metros rodados: ");
    scanf("%f", &kmr);

    vtot = taxab + (taxakm * kmr);

     printf("O valor total do aluguel �: R$ %.2f\n", vtot);

    return 0;
}
