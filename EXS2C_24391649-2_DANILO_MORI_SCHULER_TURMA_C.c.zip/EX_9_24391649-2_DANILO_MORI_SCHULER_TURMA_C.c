#include <stdio.h>

int ehPrimo(int numero){
    
    if (numero <= 1) return 0;
    
    if (numero == 2) return 1;

    if (numero % 2 == 0) return 0;

    for (int i = 3; i * i <= numero; i += 2) {
        if (numero % i == 0) return 0;
    }
    return 1;
}

int main() {
    int numero;

    printf("Digite um n�mero: ");
    scanf("%d", &numero);

    if (ehPrimo(numero)) {
        printf("%d � um n�mero primo.\n", numero);
    } else {
        printf("%d n�o � um n�mero primo.\n", numero);
    }

    return 0;
}
