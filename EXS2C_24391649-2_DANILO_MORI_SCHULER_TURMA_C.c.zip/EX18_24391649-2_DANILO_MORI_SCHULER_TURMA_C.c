#include <stdio.h>


double potencia(double base, int exp) {
    double resultado = 1.0;
    for (int i = 0; i < exp; i++) {
        resultado *= base;
    }
    return resultado;
}

int main(){
    double C, i, t, M;
    
    printf("Digite o capital inicial (C): ");
    scanf("%lf", &C);
    
    printf("Digite a taxa de juros (i) em porcentagem: ");
    scanf("%lf", &i);
    
    printf("Digite o n�mero de per�odos (t): ");
    scanf("%lf", &t);
    
    i = i / 100;
    
    M = C * potencia(1 + i, (int)t);
    
    printf("O montante acumulado ap�s %.0f per�odos �: %.2f\n", t, M);
    
    return 0;
}
