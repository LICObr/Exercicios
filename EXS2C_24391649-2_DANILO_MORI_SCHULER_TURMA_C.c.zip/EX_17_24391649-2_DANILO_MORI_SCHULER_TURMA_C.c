#include <stdio.h>

int main() {
    char codigo[9];
    int i;
    int valido = 1;

    printf("Digite o c�digo da encomenda (8 d�gitos): ");
    scanf("%8s", codigo);

    for (i = 0; codigo[i] != '\0'; i++);

    if (i != 8) {
        valido = 0;
    }
     if (codigo[0] != '1') {
        valido = 0;
    }
    for (i = 0; i < 8; i++) {
        if (codigo[i] < '0' || codigo[i] > '9') {
            valido = 0;
            break;
        }
    }
    if (valido) {
        printf("C�digo v�lido.\n");
    } else {
        printf("C�digo inv�lido.\n");
    }

    return 0;
}
