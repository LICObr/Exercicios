#include <stdio.h>

int main() {
    double v, t, a, p;
    int n = 12; // Mensal
    
    printf("Digite o valor do empr�stimo: ");
    scanf("%lf", &v);
    
    printf("Digite a taxa de juros anual (em porcentagem): ");
    scanf("%lf", &t);
    
    printf("Digite o n�mero de anos para o empr�stimo: ");
    scanf("%lf", &a);
    
    double tm = (t / 100) / n;
    int np = n * a;
    
    if (tm == 0) {
        p = v / np;
    } else {
        p = v * tm / (1 - 1 / (1 + tm));
    }
    
    printf("O valor da presta��o mensal �: %.2f\n", p);
    
    return 0;
}
